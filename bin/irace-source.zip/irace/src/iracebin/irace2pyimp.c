#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>

#define R_CODE "library(irace);irace2pyimp_cmdline()"
#include "irace.h"



